# Google Drive — jednorazowa konfiguracja AIDE

AIDE używa oficjalnego Google Identity Services i Google Drive API.
Do działania potrzebny jest własny OAuth Client ID typu **Web application**.

## 1. Google Cloud
1. Otwórz Google Cloud Console.
2. Utwórz nowy projekt, np. `AIDE Ubezpieczenia`.
3. Włącz **Google Drive API**.
4. Skonfiguruj ekran zgody OAuth / Google Auth Platform.
5. Utwórz **OAuth Client ID → Web application**.
6. W `Authorized JavaScript origins` dodaj adres Twojej aplikacji GitHub Pages, np.:
   `https://TWOJ_LOGIN.github.io`
   (wpisz dokładny origin, bez ścieżki repozytorium).
7. Skopiuj Client ID kończący się na:
   `.apps.googleusercontent.com`

## 2. W AIDE
1. Otwórz `Kopia`.
2. Wklej Client ID.
3. Kliknij `Zapisz Client ID`.
4. Kliknij `Połącz Google Drive`.
5. Zaloguj się na konto Google i zaakceptuj dostęp.
6. Włącz `Automatyczna kopia po każdej zmianie`.

AIDE używa zakresu `drive.file`, więc aplikacja ma dostęp tylko do plików utworzonych/otwartych przez AIDE, a nie do całej zawartości Twojego Dysku.

## Gdzie jest kopia
Na Dysku Google AIDE tworzy folder:
`AIDE Ubezpieczenia`

i w nim aktualizuje plik:
`AIDE-backup.aide`

Kopia zawiera zaszyfrowany sejf AIDE i sól potrzebną do odtworzenia. Do odszyfrowania nadal wymagany jest PIN AIDE.

## Ważne
PWA nie może niezawodnie robić kopii, gdy jest całkowicie zamknięta. Autokopia uruchamia się po zmianie danych, kiedy AIDE jest otwarte i połączone z Google.
