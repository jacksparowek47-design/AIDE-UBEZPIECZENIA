# AIDE Ubezpieczenia — PWA

Bez Android Studio, Gradle i YML.

## Instalacja przez GitHub Pages
1. Utwórz repozytorium `AIDE-Ubezpieczenia`.
2. Wgraj 5 plików: `index.html`, `manifest.webmanifest`, `sw.js`, `icon-192.png`, `icon-512.png`.
3. GitHub: Settings → Pages.
4. Source: Deploy from a branch.
5. Branch: main, folder: /(root), Save.
6. Otwórz podany adres w Chrome na Androidzie.
7. Wybierz „Zainstaluj AIDE” albo Chrome → „Dodaj do ekranu głównego / Zainstaluj aplikację”.

## Funkcje
Klienci, PESEL, adres, e-mail, telefon, pojazd, polisy, terminy, wyszukiwarka, PIN, AES-GCM, PBKDF2, szyfrowany backup/import, jasny/ciemny motyw, telefon/SMS/WhatsApp, offline.

## Ograniczenie
Bez serwera PWA nie może niezawodnie planować powiadomień, gdy aplikacja jest całkowicie zamknięta. Terminy są widoczne w aplikacji, a powiadomienie można wywołać po jej otwarciu.


## Google Drive
Ta wersja potrafi tworzyć zaszyfrowaną kopię na Google Drive.
Instrukcja jednorazowej konfiguracji znajduje się w `GOOGLE_DRIVE_SETUP.md`.
